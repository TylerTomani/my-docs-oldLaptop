const dropResources = document.querySelectorAll('.dropResource')
dropResources.forEach(el => {
    el.addEventListener('click', e => {
        toggleTopics(e)

    })
})
function getResourceContainer(parent){
    if(parent.classList.contains('resource-container')){
        return parent
    } else if (parent.parentElement){
        return getResourceContainer(parent.parentElement)
    } else {
        return null
    }
}
function toggleTopics(e){
    
}